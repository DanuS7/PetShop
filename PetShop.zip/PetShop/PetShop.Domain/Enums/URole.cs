﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetShop.Domain.Enums
{
    public enum URole
    {
        user = 0,
        moderator = 1,
        admin = 2
    }
}
